package com.microservicec.microservicec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceCApplicationTests {

	@Test
	void contextLoads() {
	}

}
